#include <iostream>
#include <string>

using namespace std;

struct Alumno
{
    string codigo;
    string nombre;
    float nota[2];
    float prom;
};